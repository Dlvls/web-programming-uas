<?php

namespace App\Controllers;

use App\Models\IphoneModel;

class Admin extends BaseController
{
    public function index()
    {
        return view('admin/index');
    }

    public function crud()
    {
        return view('admin/index-vito');
    }

    public function dashboard()
    {
        $Product = new IphoneModel();
        $data = [
            'title' => 'Dashboard | Belajar CI4',
            'page' => 'dashboard',
            'total_product' => $Product->totProduct(),
            'total_product_cat' => $Product->totProductCat()
        ];
        return view('admin/dashboard', $data);
    }

    public function product_data()
    {
        $Product = new IphoneModel();
        $data = [
            'title' => 'Data Produk | Belajar CI4',
            'page' => 'product_data',
            'product' => $Product->getProduct()
        ];

        return view('admin/product_data', $data);
    }

    public function insert_data()
    {
        $Product = new IphoneModel();

        $validation = $this->validate([
            'product_img' => [
                'uploaded[product_img]',
                'mime_in[product_img,image/jpg,image/jpeg,image/png]'
            ]
        ]);
 
        if ($validation == FALSE) {
            $data = array(
                'product_name'          => $this->request->getPost('product_name'),
                'product_category'      => $this->request->getPost('product_category'),
                'product_description'   => $this->request->getPost('product_description'),
                'product_price'         => $this->request->getPost('product_price'),
                'product_img'           => "NoImage.png"
            );
        }
        else {
            $upload = $this->request->getFile('product_img');
            $upload->move(WRITEPATH . '../public/product-img/');
            $data = array(
                'product_name'          => $this->request->getPost('product_name'),
                'product_category'      => $this->request->getPost('product_category'),
                'product_description'   => $this->request->getPost('product_description'),
                'product_price'         => $this->request->getPost('product_price'),
                'product_img'           => $upload->getName()
            );
        }

        $Product->insertProduct($data);
        return redirect()->to('/admin/product_data');
    }
 
    public function update_data()
    {
        $Product = new IphoneModel();
        $id = $this->request->getPost('product_id');
        $data = array(
            'product_name'          => $this->request->getPost('product_name'),
            'product_category'      => $this->request->getPost('product_category'),
            'product_description'   => $this->request->getPost('product_description'),
            'product_price'         => $this->request->getPost('product_price'),
            'product_img'           => $this->request->getPost('product_img')
        );
        $Product->updateProduct($data, $id);
        return redirect()->to('/admin/product_data');
    }

    public function delete_data()
    {
        $Product = new IphoneModel();
        $id = $this->request->getPost('product_id');
        $Product->deleteProduct($id);
        return redirect()->to('/admin/product_data');
    }

    /*

    public function product_import()
    {
        $Product = $this->IphoneModel->findAll();

        $data = [
            'title' => 'Import Data Produk | Belajar CI4',
            'page' => 'product_import',
            'product' => $Product
        ];

        return view('admin/product_import', $data);
    }

    */

}