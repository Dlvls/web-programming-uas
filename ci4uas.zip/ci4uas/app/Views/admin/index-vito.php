<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$title;?></title>

    <link href="/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="/assets/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="/assets/vendor/jquery/jquery.min.js"></script>
    <link href="/assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <script>
    $(document).ready(function() {
        // Sembunyikan alert validasi kosong
        $("#kosong").hide();
    });
    </script>


</head>

<body id="page-top">

            

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item <?=($page == 'product_data') ? 'active':''; ?>">
                <div id="collapseTwo" class="collapse <?=($page == 'product_data') ? 'show':''; ?>"
                    aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <!-- <h6 class="collapse-header">Custom Components:</h6> -->
    
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>


                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Halo,
                                    SESSION['user_name'] </span>
                                <img class="img-profile rounded-circle" src="../assets/img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->


                <!-- BODY -->
                <?php if (session()->getFlashdata('add_success')) : ?>
<div class="container-fluid">
    <div class="row" style="display: flex; justify-content: flex-end">
        <div class="col-lg-3">
            <div class="alert alert-success alert-dismissible fade show alertnotif" role="alert">
                <strong> <?= session()->getFlashdata('add_success'); ?> </strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data <i class="fa fa-angle-right"></i> <strong>Lihat</strong>
        </h1>
    </div>

    <div class="d-sm-flex align-items-center mb-4">
        <a href="#" data-toggle="modal" data-target="#addmodal" class="d-sm-inline-block btn btn-sm btn-success shadow-sm mr-2">
            <i class="fas fa-plus fa-sm"></i> Tambah
        </a>
        <a href="admin-data-import.php" class="d-sm-inline-block btn btn-sm btn-warning shadow-sm mr-2">
            <i class="fas fa-upload fa-sm"></i> Import
        </a>
        <a href="admin-class-export.php" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm mr-2">
            <i class="fas fa-download fa-sm"></i> Download
        </a>
    </div>


    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Data Produk</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Gambar</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Gambar</th>
                            <th>Opsi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php foreach ($product as $row): ?>
                        <tr>
                            <td><?=$row['product_id']?></td>
                            <td>
                                <a href="#" data-toggle="modal" data-target="#viewmodal"
                                    data-pid="<?=$row['product_id'];?>" data-pname="<?=$row['product_name'];?>"
                                    data-pcategory="<?=$row['product_category'];?>"
                                    data-pdescription="<?=$row['product_description'];?>"
                                    data-pprice="<?=$row['product_price'];?>"
                                    data-pimg="../product-img/<?=$row['product_img'];?>" class="viewID"><?=$row['product_name']?></a>
                            </td>
                            <td><?=$row['product_category']?></td>
                            <td><?=number_format($row['product_price'])?></td>
                            <td><img src="/product-img/<?=$row['product_img']?>" style="width:100px; height:100px; object-fit:cover"></td>
                            <td>
                                <a href="#" data-toggle="modal" data-target="#editmodal"
                                    data-eid="<?=$row['product_id'];?>" data-ename="<?=$row['product_name'];?>"
                                    data-ecategory="<?=$row['product_category'];?>"
                                    data-edescription="<?=$row['product_description'];?>"
                                    data-eprice="<?=$row['product_price'];?>"
                                    data-eimg="../product-img/<?=$row['product_img'];?>" class="editID">
                                    <button type="button" class="btn ink-reaction btn-floating-action btn-circle btn-primary" data-toggle="tooltip" data-placement="bottom" title="Edit">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                </a>

                                <a href="#" data-toggle="modal" data-target="#deletemodal"
                                    data-did="<?=$row['product_id'];?>" class="deleteID">
                                    <button type="button" class="btn ink-reaction btn-floating-action btn-circle btn-danger" data-toggle="tooltip" data-placement="bottom" title="Hapus">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->


<!-- Add Modal-->
<div class="modal fade" id="addmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Data</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Cross Site Request Forgery enctype="multipart/form-data" -->
                <form action="/admin/insert_data" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Nama Produk</label>
                        <input type="text" name="product_name" class="form-control" placeholder="Nama Produk" autofocus required>
                    </div>

                    <div class="form-group">
                        <label>Kategori</label>
                        <select class="form-control" name="product_category" required>
                            <option value="32GB">32GB</option>
                            <option value="64GB">64GB</option>
                            <option value="132GB">132GB</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Deskripsi</label>
                        <textarea class="form-control" name="product_description"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" name="product_price" id="product_price" class="form-control"
                            placeholder="Harga Produk" required>
                    </div>

                    <div class="form-group">
                        <label>File Gambar</label>
                        <input type="file" name="product_img" accept=".jpg,.jpeg,.png" class="form-control-file" placeholder="Gambar Produk">
                        <i style="color:red">*Gambar harus file .jpg / .png <br>**Abaikan jika tidak ada gambar produk</i>
                        <!-- <input type="text" name="product_img" class="form-control" placeholder="Nama File" required> -->
                    </div>

                    <div class="row">
                        <div class="col">
                            <button class="form-control btn btn-danger" data-dismiss="modal">Batal</button>
                        </div>
                        <div class="col">
                            <button class="form-control btn btn-success" type="submit">Tambah</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- View Modal-->
<div class="modal fade" id="viewmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Produk</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">

                <form method="post" enctype="multipart/form-data" action="admin-class-crud.php">
                    <div class="form-group">
                        <label>Nama Produk</label>
                        <input type="text" name="p_name" id="pname" class="form-control" placeholder="Nama Produk" disabled="">
                    </div>

                    <div class="form-group">
                        <label>Kategori</label>
                        <input type="number" name="p_category" id="pcategory" class="form-control" placeholder="Kategori Produk" disabled="">
                    </div>

                    <div class="form-group">
                        <label>Deskripsi</label>
                        <textarea class="form-control" name="p_description" id="pdescription" disabled=""></textarea>
                    </div>

                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" name="p_price" id="pprice" class="form-control" placeholder="Harga Produk" disabled="">
                    </div>

                    <div class="form-group">
                        <label>Gambar</label>
                        <div class="form-group">
                            <img id="pimgs" src="" style="width:200px;">
                        </div>
                    </div>

                    <input type="text" name="p_id" id="pid" hidden required>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal-->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Data</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">

                <form method="post" enctype="multipart/form-data" action="/admin/update_data">
                    <div class="form-group">
                        <label>Nama Produk</label>
                        <input type="text" name="product_name" id="ename" class="form-control" placeholder="Nama Produk" required>
                    </div>

                    <div class="form-group">
                        <label>Kategori</label>
                        <select class="form-control" name="product_category" id="ecategory" required>
                            <option value="32GB">32GB</option>
                            <option value="64GB">64GB</option>
                            <option value="132GB">132GB</option>

                        </select>
                    </div>

                    

                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" step="any" name="product_price" id="eprice" class="form-control" placeholder="Harga Produk" required>
                    </div>

                    <div class="form-group">
                        <label>File Gambar</label>
                        <div class="form-group">
                            <img id="eimgs" src="" style="width:200px;">
                        </div>

                        <!-- <input class="form-control-file" type="file" name="p_img" accept="image/*"> -->
                        <i style="color:red">*Gambar harus file .jpg / .png <br>**Abaikan jika tidak merubah gambar produk</i>

                        <input type="text" name="product_img" class="form-control" placeholder="Nama File" required>
                    </div>


                    <input type="text" name="product_id" id="eid" hidden required>


                    <div class="row">
                        <div class="col">
                            <button class="form-control btn btn-danger" data-dismiss="modal">Batal</button>
                        </div>
                        <div class="col">
                            <button class="form-control btn btn-success" type="submit">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Modal-->
<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Konfirmasi Hapus</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form method="post" action="/admin/delete_data">
                <div class="modal-body">
                    <i class="text-danger">Anda yakin Ingin menghapus data produk ini?</i>
                </div>

                <input type="text" name="product_id" id="did" hidden required>

                <div class="modal-footer">
                    <button class="btn btn-danger" type="button" data-dismiss="modal">Batal</button>
                    <button class="btn btn-success" type="submit">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>


            </div>
            <!-- End of Main Content -->



        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Logout</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Pilih "Logout" jika ingin mengakhiri sesi ini.</div>
                <div class="modal-footer">
                    <button class="btn btn-danger" type="button" data-dismiss="modal">Batal</button>
                    <a class="btn btn-success" href="../logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>


    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="/assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="/assets/js/sb-admin-2.min.js"></script>

    <!-- <script src="../assets/vendor/chart.js/Chart.min.js"></script>
    <script src="../assets/js/demo/chart-area-demo.js"></script>
    <script src="../assets/js/demo/chart-pie-demo.js"></script> -->
    <script src="/assets/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="/assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="/assets/js/demo/datatables-demo.js"></script>


    <script type="text/javascript">
    $(".viewID").click(function() {
        var pid = $(this).data('pid');
        $("#pid").val(pid);

        var pname = $(this).data('pname');
        $("#pname").val(pname);

        var pcategory = $(this).data('pcategory');
        $("#pcategory").val(pcategory);

        var pdescription = $(this).data('pdescription');
        $("#pdescription").val(pdescription);

        var pprice = $(this).data('pprice');
        $("#pprice").val(pprice);

        var pimg = $(this).data('pimg');
        $("#pimgs").attr("src", pimg);

        $('#viewmodal').modal('show');
    });
    </script>

    <script type="text/javascript">
    $(".editID").click(function() {
        var eid = $(this).data('eid');
        $("#eid").val(eid);

        var ename = $(this).data('ename');
        $("#ename").val(ename);

        var ecategory = $(this).data('ecategory');
        $("#ecategory").val(ecategory);

        var edescription = $(this).data('edescription');
        $("#edescription").val(edescription);

        var eprice = $(this).data('eprice');
        $("#eprice").val(eprice);

        var eimg = $(this).data('eimg');
        $("#eimgs").attr("src", eimg);

        $('#editmodal').modal('show');
    });
    </script>


    <script type="text/javascript">
    $(".deleteID").click(function() {
        var did = $(this).data('did');
        $("#did").val(did);

        $('#deletemodal').modal('show');
    });
    </script>


    <!-- Alert auto close -->
    <script type="text/javascript">
    window.setTimeout(function() {
        $(".alertnotif").fadeTo(300, 0).slideUp(300, function() {
            $(this).remove();
        });
    }, 3000);
    </script>
</body>

</html>